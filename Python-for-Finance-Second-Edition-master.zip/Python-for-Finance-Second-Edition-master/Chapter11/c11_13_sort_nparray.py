
"""
  Name     : c11_13_sor_nparray.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017
  email    : yany@canisius.edu
             paulyxy@hotmail.com
"""
import numpy as np
a = np.array([[1,-4],[9,10]])
b=np.sort(a)                

print("a=",a)
print("b=",b)
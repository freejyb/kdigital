# -*- coding: utf-8 -*-
"""
  Name     : c1_11_import_math_print_dir.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017
  email    : yany@canisius.edu
             paulyxy@hotmail.com
"""
import math
x=dir(math)
print(x)
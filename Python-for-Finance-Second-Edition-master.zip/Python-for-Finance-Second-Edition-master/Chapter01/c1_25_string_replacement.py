# -*- coding: utf-8 -*-
"""
  Name     : c1_26_string_replacement.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017
  email    : yany@canisius.edu
             paulyxy@hotmail.com
"""
import re
x="abc"
print("x=",x)
y=re.sub("a","9",x)
print("y=",y)



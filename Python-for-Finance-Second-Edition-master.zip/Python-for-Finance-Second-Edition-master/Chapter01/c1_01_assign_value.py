# -*- coding: utf-8 -*-
"""
  Name     : c1_01_assign_value.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017
  email    : yany@canisius.edu
             paulyxy@hotmail.com
"""

pv=100
fv=pv*(1+0.1)**20

print(fv)
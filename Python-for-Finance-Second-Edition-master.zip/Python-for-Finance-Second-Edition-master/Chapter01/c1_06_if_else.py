# -*- coding: utf-8 -*-
"""
  Name     : c1_06_if_else.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017
  email    : yany@canisius.edu
             paulyxy@hotmail.com
"""

import numpy as np
cashFlows=np.array([-100,50,40,30])
for cash in cashFlows:
    print(cash)
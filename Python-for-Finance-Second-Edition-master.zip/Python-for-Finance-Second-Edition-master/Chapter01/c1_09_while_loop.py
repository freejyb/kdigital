# -*- coding: utf-8 -*-
"""
  Name     : c1_09_while_loop.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017
  email    : yany@canisius.edu
             paulyxy@hotmail.com
"""

i=1
while(i<10):
    print(i)
    i+=1
# -*- coding: utf-8 -*-
"""
  Name     : c1_16_logic_and_logic_or.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017
  email    : yany@canisius.edu
             paulyxy@hotmail.com
"""
a=9
b=-8

if(a>0 and b>0):
    print("both positive")
if(a>0 or b>0):
    print("at least one is positive")
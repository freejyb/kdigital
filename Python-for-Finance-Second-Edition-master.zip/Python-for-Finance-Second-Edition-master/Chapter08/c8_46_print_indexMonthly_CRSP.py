import pandas as pd
x=pd.read_pickle("c:/temp/indexMonthly.pkl")
print(x.head())

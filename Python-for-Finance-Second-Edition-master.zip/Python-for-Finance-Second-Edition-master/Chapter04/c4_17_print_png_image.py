# -*- coding: utf-8 -*-
"""
  Name     : c4_17_print_png_image.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017
  email    : yany@canisius.edu
             paulyxy@hotmail.com
"""
from PIL import Image                                                                                
img = Image.open('c:/temp/fun.png')
img.show() 



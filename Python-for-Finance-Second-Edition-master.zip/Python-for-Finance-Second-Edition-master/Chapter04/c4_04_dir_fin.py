# -*- coding: utf-8 -*-
"""
  Name     : c4_03_dir_fin.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017
  email    : yany@canisius.edu
             paulyxy@hotmail.com
"""
import matplotlib.finance as fin
print(dir(fin))
